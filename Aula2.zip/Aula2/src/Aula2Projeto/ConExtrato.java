package Aula2Projeto;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

public class ConExtrato extends JFrame implements ActionListener {
	//Login login;
	JTextArea area = new JTextArea (15,30);
	
	boolean bool = true;  
	
	//TelaSenha senha;
	
	JLabel lOpcoes;
	JButton b7;
	JButton b15;
	JLabel lPeriodo;
	JLabel lAte;
	JButton bCorrigir;
	JButton bMenu;
	JButton bImprimir;
	
	//Boolean cliquePortL = false;
	//Boolean cliqueInglL = false;
	//Boolean cliqueEspaL = false;
	
	//ResourceBundle bn = null;
	//ResourceBundle bn2 = null;
	
	public MaskFormatter Mascara(String Mascara){  
        
	       MaskFormatter F_Mascara = new MaskFormatter();  
	       try{  
	           F_Mascara.setMask(Mascara); //Atribui a mascara  
	           F_Mascara.setPlaceholderCharacter(' '); //Caracter para preencimento   
	       }  
	       catch (Exception excecao) {  
	       excecao.printStackTrace();  
	       }   
	       return F_Mascara;  
	}  
	
	JFormattedTextField fTData1 = new JFormattedTextField(Mascara("##/##/####"));
	Date minhaData = new Date();
	long mili = minhaData.getTime();
	java.sql.Date dataSQL = new java.sql.Date(mili);
	JFormattedTextField fTData2 = new JFormattedTextField(dataSQL);
	
	public ConExtrato(){
		super("Consulta Extrato");
		Container con = getContentPane();
		con.setLayout(new FlowLayout());
		
		//bn = ResourceBundle.getBundle("Pacote1.ingles", new Locale("en","us"));
		//bn2 = ResourceBundle.getBundle("Pacote1.espanhol", new Locale("es","es"));

		lOpcoes = new JLabel("Escolha uma das op��es abaixo");
		b7 = new JButton("7 dias");
		b7.addActionListener(this);
		b15 = new JButton("15 dias");
		b15.addActionListener(this);
		lPeriodo = new JLabel("Digite o periodo que deseja consultar");
		
		fTData1.setColumns(6);
		
		lAte = new JLabel("At�");
		
		fTData2.setColumns(6);
		
		bCorrigir = new JButton("Corrigir");
		bCorrigir.addActionListener(this);
		bMenu = new JButton("Menu");
		bMenu.addActionListener(this);
		bImprimir = new JButton("Imprimir");
		bImprimir.addActionListener(this);
		
		con.add(lOpcoes);
		con.add(b7);
		con.add(b15);
		con.add(lPeriodo);
		con.add(fTData1);
		con.add(lAte);
		con.add(fTData2);
		con.add(bCorrigir);
		con.add(bImprimir);
		con.add(bMenu);
		
		fTData2.setEnabled(false);
		
		this.setVisible(true);
		this.setLocation(500, 200);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(270, 210);
	}
	


	public void actionPerformed(ActionEvent event) {
		//int codCliente = Integer.parseInt(login.acesso);
		//System.out.println(login.acesso);
		ExtratoContaDAO eCDAO = new ExtratoContaDAO();
		//eCDAO.setCodCliente(codCliente);
		try {
			if (event.getSource() == b7) {
				//area.setText(eCDAO.consultarExtrato7Dias());
				b15.setEnabled(false);
				fTData1.setEnabled(false);
				bool = false;
			}
		} catch (Exception acx) {
		}

		try {
			if (event.getSource() == b15) {
				area.setText(eCDAO.consultarExtrato15Dias());
				b7.setEnabled(false);
				fTData1.setEnabled(false);
				//fTData2.setEnabled(false);
				bool = false;
			}
		} catch (Exception acx) {
		}
		
		try {
			if (event.getSource() == bCorrigir) {
				fTData1.setText("");
				//fTData2.setText("");
				b7.setEnabled(true);
				b15.setEnabled(true);
				fTData1.setEnabled(true);
				//fTData2.setEnabled(true);
				bool = true;
			}
		} catch (Exception acx) {
		}
		
		try {
			if (event.getSource() == bMenu) {
				//senha.menu.setVisible(true);
				/*if (cliqueInglL == true) {
					cliquePortL = false;
					cliqueEspaL = false;					
				} else if (cliquePortL == true) {
					cliqueEspaL = false;
					cliqueInglL = false;
				} else if (cliqueEspaL == true) {
					cliquePortL = false;
					cliqueInglL = false;
				}*/
				this.setVisible(false);
			}
		} catch (Exception acx) {
		} 
		
		try {
			if (event.getSource() == bImprimir) {

				if(bool == true){
					String dataS1 = fTData1.getText();
					//String dataS2 = fTData2.getName();
					
					//Date data1 = ExtratoContaDAO.formataData(dataS1);
					//System.out.println(data1);
					SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
					//SimpleDateFormat format2 = new SimpleDateFormat("dd/MM/yyyy");
					long data1 = (format.parse(dataS1).getTime());
					java.sql.Date dataSQL = new java.sql.Date(data1);
					//System.out.println(dataSQL);
					//Date data1 = new java.sql.Date(format.parse(dataS1).getTime());
					//eCDAO.setData1(dataSQL);
					//System.out.println("Data1");
					//Date data2 = ExtratoContaDAO.formataData(dataS2);
					//Date data2 = new java.sql.Date(format2.parse(dataS2).getTime());
					//System.out.println("Data2");
					//long data2 = (format2.parse(dataS2).getTime());
					//java.sql.Date dataSQL2 = new java.sql.Date(data2);
					//System.out.println(dataSQL2);
					//eCDAO.setData2(dataSQL2);
					//System.out.println("Consultou?");
					area.setText(eCDAO.consultarExtrato());
					//System.out.println("Foi");
					
				}
				
				
				JOptionPane.showMessageDialog(null,new JScrollPane(area),"Extrato",JOptionPane.PLAIN_MESSAGE);
				/*if (cliqueInglL == true) {
					JOptionPane
					.showMessageDialog(null, bn.getString("ingles.extrato.m1"),
							bn.getString("ingles.extrato.mt1"),
							JOptionPane.INFORMATION_MESSAGE);	
				} else if (cliquePortL == true) {
					JOptionPane
					.showMessageDialog(null, "Extrato Imprimido!",
							"Impress�o Extrato",
							JOptionPane.INFORMATION_MESSAGE);

				} else if (cliqueEspaL == true) {
					JOptionPane
					.showMessageDialog(null, bn2.getString("espanhol.extrato.m1"),
							bn2.getString("espanhol.extrato.mt1"),
							JOptionPane.INFORMATION_MESSAGE);	
				}*/
			}
		} catch (Exception acx) {
		}

	}
}