package Aula2Projeto;

import arqdesis_aula02b.Cliente;

public class ExtratoContaTeste {
	public static void main(String[] args) {
		ExtratoConta extrato = new ExtratoConta();
		extrato.setDebiCredi("Debito");
		extrato.setNumDocum(78);
		extrato.setValorOpera(200);
		extrato.setSaldoDia(500);
		extrato.setCodCliente(1020);
		extrato.criar();
		extrato.carregar();
	}
}
