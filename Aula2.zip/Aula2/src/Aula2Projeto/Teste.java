package Aula2Projeto;

public class Teste {
	static ConExtrato test;
	public static void main(String[] args) {
		test = new ConExtrato();
		test.setVisible(true);
	}
}
