package Aula2Projeto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;

import arqdesis_aula02b.ClienteDAO;
import arqdesis_aula02b.ClienteTO;

public class ExtratoConta {
	// atributos da classe
		private int codExtratoConta;
		private Date dataExtrato;
		private String debiCredi;
		private int numDocum;
		private int valorOpera;
		private int saldoDia;
		private String tipoExtrato;
		private int codCliente;
		private Connection conn;
		private PreparedStatement st;
		private MysqlConnect db;
		private Date data1;
		private Date data2;
		

		// construtor basico
		public ExtratoConta() {
			this.codExtratoConta = 0;
			this.db = new MysqlConnect();
			this.conn = db.getConnection();
		}

		// construtor padrao
		//Date dataExtrato,
		public ExtratoConta(int codExtratoConta, 
				String debiCredi,int numDocum, int valorOpera, 
				int saldoDia, int codCliente, String tipoExtrato) {
			this.codExtratoConta = codExtratoConta;
			//this.dataExtrato = dataExtrato;
			this.debiCredi = debiCredi;
			this.numDocum = numDocum;
			this.valorOpera = valorOpera;
			this.saldoDia = saldoDia;
			this.codCliente = codCliente;
			this.tipoExtrato = tipoExtrato;
			this.db = new MysqlConnect();
			this.conn = db.getConnection();
		}

		// set's
		public void setCodExtratoConta(int codExtratoConta) {
			this.codExtratoConta = codExtratoConta;
		}

		public void setDataExtrato(Date dataExtrato) {
			this.dataExtrato = dataExtrato;
		}

		public void setDebiCredi(String debiCredi) {
			this.debiCredi = debiCredi;
		}

		public void setNumDocum(int numDocum) {
			this.numDocum = numDocum;
		}
		
		public void setValorOpera(int valorOpera) {
			this.valorOpera = valorOpera;
		}

		public void setSaldoDia(int saldoDia) {
			this.saldoDia = saldoDia;
		}
		
		public void setTipoExtrato(String tipoExtrato) {
			this.tipoExtrato = tipoExtrato;
		}
		
		public void setCodCliente(int codCliente) {
			this.codCliente = codCliente;
		}
		
		public void setData1(Date data1) {
			this.data1 = data1;
		}
		
		public void setData2(Date data2) {
			this.data2 = data2;
		}
		
		// get's
		public int getCodExtratoConta() {
			return this.codExtratoConta;
		}

		public Date getDataExtrato() {
			return this.dataExtrato;
		}
		
		public String getDebiCredi() {
			return this.debiCredi;
		}
		
		public int getNumDocum() {
			return this.numDocum;
		}

		public int getValorOpera() {
			return this.valorOpera;
		}
		
		public int getSaldoDia() {
			return this.saldoDia;
		}
		
		public String getTipoExtrato() {
			return this.tipoExtrato;
		}
		
		public int getCodCliente() {
			return this.codCliente;
		}
		
		public Date getData1() {
			return this.data1;
		}
		
		public Date getData2() {
			return this.data2;
		}
		
		public void criar() {
			ExtratoContaDAO dao = new ExtratoContaDAO();
			ExtratoContaTO to = new ExtratoContaTO();
			to.setDebiCredi(debiCredi);
			to.setNumDocum(numDocum);
			to.setValorOpera(valorOpera);
			to.setSaldoDia(saldoDia);
			to.setCodCliente(codCliente);
			dao.incluir(to);
		}
		
		public void carregar() {
			ExtratoContaDAO dao = new ExtratoContaDAO();
			System.out.println(dao.consultarExtrato7Dias(codCliente));
		}

		
}
