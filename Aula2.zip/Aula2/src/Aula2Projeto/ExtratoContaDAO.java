package Aula2Projeto;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
//import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class ExtratoContaDAO {
	private Connection conn;
	private PreparedStatement st;
	private MysqlConnect db;
	private Date data1;
	private Date data2;

	// construtor basico
	public ExtratoContaDAO() {
		this.db = new MysqlConnect();
		this.conn = db.getConnection();
	}

	
	public Date getData1() {
		return this.data1;
	}
	
	public Date getData2() {
		return this.data2;
	}

	 // incluir
	public void incluir(ExtratoContaTO to) {
		Date minhaData = new Date();
		long mili = minhaData.getTime();
		java.sql.Date dataSQL = new java.sql.Date(mili);
		
	      boolean sucesso = false;
	      try {
	         String sql = "INSERT INTO tabExtratoConta (dataExtrato,"
	         		+ " debiCredi, numDocum, valorOpera, saldoDia,"
	         		+ " tipoExtrato, codCliente) "
	         		+ "VALUES (?, ?, ?, ?, ?, ?, ?)";
	         st         = conn.prepareStatement(sql);
	         st.setDate(1,dataSQL);
	         st.setString(2,to.getDebiCredi());
	         st.setInt(3,to.getNumDocum());
	         st.setInt(4,to.getValorOpera());
	         st.setInt(5,to.getSaldoDia());
	         st.setString(6,to.getTipoExtrato());
	         st.setInt(7,to.getCodCliente());
	         st.executeUpdate();
	         sucesso = true;
	         
	         
	         //Estatistico DAO
	         //EstatisticoDAO eDAO = new EstatisticoDAO();
	         //eDAO.setDataOpera(dataSQL);
	         //eDAO.incluir();
	         //----------------
	         
	       st.close();
	      }
	      catch(Exception e){ e.printStackTrace(); }
	      db.closeConnection();
	   }
	
	public static Date alterarData (int dias,Date data) {  
		   Calendar calendar = Calendar.getInstance();  
		   calendar.setTime(data);  
		   calendar.add(Calendar.DATE, dias);  
		  
		   return calendar.getTime();  
		} 
	
	public String consultarExtrato7Dias(int codCliente) {
		Date minhaData = alterarData(-7,new Date());
		long mili = minhaData.getTime();
		java.sql.Date dataSQL = new java.sql.Date(mili);
		//System.out.println(dataSQL);
	      ResultSet rs;
	      String retorno  = "Extrato nao localizado !";
	      String conteudo = "";
	      try {
	    	  
	         String sql = "select * from tabExtratoConta where dataExtrato >= '"+ dataSQL+
	        		 "' and codCliente = ?";
	         st         = conn.prepareStatement(sql);
	         st.setInt(1, codCliente);
	         rs         = st.executeQuery();
	         while (rs.next()) { // so espero um resultado por isso uso o IF para verificar
	            /*setDataExtrato(rs.getDate("dataExtrato"));	// coloca-se os dados
	            setDebiCredi(rs.getString("debiCredi"));
	            setNumDocum(rs.getInt("numDocum"));
	            setValorOpera(rs.getInt("valorOpera"));
	            setSaldoDia(rs.getInt("saldoDia"));
	            setTipoExtrato(rs.getString("tipoExtrato"));*/
	            conteudo += "Tipo Extrato  : " +  rs.getString("tipoExtrato")      + "\n";
	            conteudo += "Data Extrato  : " +  rs.getDate   ("dataExtrato")    + "\n";
	            conteudo += "Debito/Credito: " +  rs.getString("debiCredi") + "\n";
	            conteudo += "N� Documento  : " +  rs.getInt("numDocum") + "\n";
	            conteudo += "Valor Opera��o: R$" +  rs.getInt("valorOpera")     + "\n";
	            conteudo += "Saldo do dia  : R$" +  rs.getInt("saldoDia")     + "\n\n";		
	            retorno = conteudo;
	         }
	         st.close(); // fecha consulta
				}
	      catch(Exception e) { e.printStackTrace(); }
	      return retorno; 
	   }
	
	public String consultarExtrato15Dias() {
		Date minhaData = alterarData(-15,new Date());
		long mili = minhaData.getTime();
		java.sql.Date dataSQL = new java.sql.Date(mili);
		//System.out.println(dataSQL);
	      ResultSet rs;
	      String retorno  = "Extrato nao localizado !";
	      String conteudo = "";
	      try {
	    	  
	         String sql = "select * from tabExtratoConta where dataExtrato >= '"+ dataSQL+
	        		 "' and codCliente = ?";
	         st         = conn.prepareStatement(sql);
	        // st.setInt(1, getCodCliente());
	         rs         = st.executeQuery();
	         while (rs.next()) { // so espero um resultado por isso uso o IF para verificar
	            //setDataExtrato(rs.getDate("dataExtrato"));	// coloca-se os dados
	            //setDebiCredi(rs.getString("debiCredi"));
	           // setNumDocum(rs.getInt("numDocum"));
	            //setValorOpera(rs.getInt("valorOpera"));
	            //setSaldoDia(rs.getInt("saldoDia"));
	            //setTipoExtrato(rs.getString("tipoExtrato"));
	            conteudo += "Tipo Extrato  : " +  rs.getString("tipoExtrato")      + "\n";
	            conteudo += "Data Extrato  : " +  rs.getDate   ("dataExtrato")    + "\n";
	            conteudo += "Debito/Credito: " +  rs.getString("debiCredi") + "\n";
	            conteudo += "N� Documento  : " +  rs.getInt("numDocum") + "\n";
	            conteudo += "Valor Opera��o: R$" +  rs.getInt("valorOpera")     + "\n";
	            conteudo += "Saldo do dia  : R$" +  rs.getInt("saldoDia")     + "\n\n";	
	            retorno = conteudo;
	         }
	         st.close(); // fecha consulta
				}
	      catch(Exception e) { e.printStackTrace(); }
	      return retorno; 
	   }
	
	public String consultarExtrato() {
		Date minhaData = new Date();
		long mili = minhaData.getTime();
		java.sql.Date dataSQL = new java.sql.Date(mili);
	      ResultSet rs;
	      String retorno  = "Extrato nao localizado !";
	      String conteudo = "";
	      try {
	    	  
	         String sql = "select * from tabExtratoConta where dataExtrato <= '"+dataSQL+"' and dataExtrato >= ?"+
	        		 " and codCliente = ?";
	         st         = conn.prepareStatement(sql);
	         st.setDate(1, (java.sql.Date) getData1());
	         //st.setDate(2, (java.sql.Date) getData2());
	        // st.setInt(2, getCodCliente());
	         rs         = st.executeQuery();
	         while (rs.next()) { // so espero um resultado por isso uso o IF para verificar
	           // setDataExtrato(rs.getDate("dataExtrato"));	// coloca-se os dados
	          //  setDebiCredi(rs.getString("debiCredi"));
	           // setNumDocum(rs.getInt("numDocum"));
	            //setValorOpera(rs.getInt("valorOpera"));
	            //setSaldoDia(rs.getInt("saldoDia"));
	           // setTipoExtrato(rs.getString("tipoExtrato"));
	            conteudo += "Tipo Extrato  : " +  rs.getString("tipoExtrato")      + "\n";
	            conteudo += "Data Extrato  : " +  rs.getDate   ("dataExtrato")    + "\n";
	            conteudo += "Debito/Credito: " +  rs.getString("debiCredi") + "\n";
	            conteudo += "N� Documento  : " +  rs.getInt("numDocum") + "\n";
	            conteudo += "Valor Opera��o: R$" +  rs.getInt("valorOpera")     + "\n";
	            conteudo += "Saldo do dia  : R$" +  rs.getInt("saldoDia")     + "\n\n";	
	            retorno = conteudo;
	         }
	         st.close(); // fecha consulta
				}
	      catch(Exception e) { e.printStackTrace(); }
	      return retorno; 
	   }
	
	public String consultarTransacoes() {
	      ResultSet rs;
	      String retorno  = "Transa��o nao localizado !";
	      String conteudo = "";
	      try {
	    	  
	         String sql = "select * from tabExtratoConta where tipoExtrato = ?"+
	        		 " and codCliente = ?";
	         st         = conn.prepareStatement(sql);
	       //  st.setString(1, getTipoExtrato());
	         //st.setDate(2, (java.sql.Date) getData2());
	        // st.setInt(2, getCodCliente());
	         rs         = st.executeQuery();
	         while (rs.next()) { // so espero um resultado por isso uso o IF para verificar
	          //  setDataExtrato(rs.getDate("dataExtrato"));	// coloca-se os dados
	           // setDebiCredi(rs.getString("debiCredi"));
	           // setNumDocum(rs.getInt("numDocum"));
	           // setValorOpera(rs.getInt("valorOpera"));
	            //setSaldoDia(rs.getInt("saldoDia"));
	           // setTipoExtrato(rs.getString("tipoExtrato"));
	            conteudo += "Tipo Extrato  : " +  rs.getString("tipoExtrato")      + "\n";
	            conteudo += "Data Extrato  : " +  rs.getDate   ("dataExtrato")    + "\n";
	            conteudo += "Debito/Credito: " +  rs.getString("debiCredi") + "\n";
	            conteudo += "N� Documento  : " +  rs.getInt("numDocum") + "\n";
	            conteudo += "Valor Opera��o: R$" +  rs.getInt("valorOpera")     + "\n";
	            conteudo += "Saldo do dia  : R$" +  rs.getInt("saldoDia")     + "\n\n";		
	            retorno = conteudo;
	         }
	         st.close(); // fecha consulta
				}
	      catch(Exception e) { e.printStackTrace(); }
	      return retorno; 
	   }
}
