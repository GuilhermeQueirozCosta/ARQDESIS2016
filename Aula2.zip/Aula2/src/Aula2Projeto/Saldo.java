package Aula2Projeto;

public class Saldo {
	// atributos da classe
	   private int codSaldo;
	   private int saldo;
	   private int codCliente;
	   
	   // construtor basico
	   public Saldo(){
	      this.codSaldo = 0;

	   }
	   
	   // construtor padrao
	   public Saldo(int codSaldo, int saldo, int codCliente){
	      this.codSaldo = codSaldo;
	      this.saldo = saldo;
	      this.codCliente = codCliente;

	   }
	   
	   // set's
	   public void setCodSaldo(int codSaldo)           { this.codSaldo    = codSaldo; }
	   public void setSaldo(int saldo) { this.saldo = saldo; }
	   public void setCodCliente(int codCliente) { this.codCliente = codCliente; }
	   
	   // get's
	   public int    getCodSaldo()    { return this.codSaldo; }
	   public int getSaldo() { return this.saldo; }
	   public int getCodCliente() { return this.codCliente; }
	   
	   public void criar() {
			SaldoDAO dao = new SaldoDAO();
			SaldoTO to = new SaldoTO();
			to.setSaldo(saldo);
			to.setCodCliente(codCliente);
			dao.incluir(to);
		}
	   
	   public void carregar() {
			SaldoDAO dao = new SaldoDAO();
			System.out.println(dao.voltarSaldo(codCliente));
			
		}
	   
	   public int saldo(){
		   SaldoDAO dao = new SaldoDAO();
		   return dao.voltarSaldo(codCliente);
	   }
	   
	   public void saque(int saque){
		   SaldoDAO dao = new SaldoDAO();
		   int valor = 0;
		   valor = saldo() - saque;
		   dao.alterar(valor, codCliente);
	   }
	   
	   
}
