package Aula2Projeto;

public class SaldoTO {
	// atributos da classe
	   private int codSaldo;
	   private int saldo;
	   private int codCliente;
	   
	   // construtor basico
	   public SaldoTO(){
	      this.codSaldo = 0;

	   }
	   
	   // construtor padrao
	   public SaldoTO(int codSaldo, int saldo, int codCliente){
	      this.codSaldo = codSaldo;
	      this.saldo = saldo;
	      this.codCliente = codCliente;

	   }
	   
	   // set's
	   public void setCodSaldo(int codSaldo)           { this.codSaldo    = codSaldo; }
	   public void setSaldo(int saldo) { this.saldo = saldo; }
	   public void setCodCliente(int codCliente) { this.codCliente = codCliente; }
	   
	   // get's
	   public int    getCodSaldo()    { return this.codSaldo; }
	   public int getSaldo() { return this.saldo; }
	   public int getCodCliente() { return this.codCliente; }
}
