package Aula2Projeto;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class SaldoDAO {
	// atributos da classe
	   private int codSaldo;
	   private int saldo;
	   private int codCliente;
	   private Connection        conn;
	   private PreparedStatement st;
	   private MysqlConnect      db;
	   
	   // construtor basico
	   public SaldoDAO(){
	      this.codSaldo = 0;
	      this.db        = new MysqlConnect();
	      this.conn      = db.getConnection();
	   }
	   
	   // construtor padrao
	   public SaldoDAO(int codSaldo, int saldo, int codCliente){
	      this.codSaldo = codSaldo;
	      this.saldo = saldo;
	      this.codCliente = codCliente;
	      this.db        = new MysqlConnect();
	      this.conn      = db.getConnection();
	   }
	   
	   // set's
	   public void setCodSaldo(int codSaldo)           { this.codSaldo    = codSaldo; }
	   public void setSaldo(int saldo) { this.saldo = saldo; }
	   public void setCodCliente(int codCliente) { this.codCliente = codCliente; }
	   
	   // get's
	   public int    getCodSaldo()    { return this.codSaldo; }
	   public int getSaldo() { return this.saldo; }
	   public int getCodCliente() { return this.codCliente; }
	   
	   // incluir
		//String meNome, String meDescricao, double mePreco, int meQuantidade
	   public void incluir(SaldoTO to) {
	      boolean sucesso = false;
	      try {
	         String sql = "INSERT INTO tabSaldo ( saldo, codCliente) VALUES (?, ?)";
	         st         = conn.prepareStatement(sql);
	         st.setInt(1,to.getSaldo());
	         st.setInt(2,to.getCodCliente());
	         st.executeUpdate();
	         sucesso = true;
	         st.close();
	      }
	      catch(Exception e){ e.printStackTrace(); }
	      db.closeConnection();
	      //return sucesso;
	   }
	   
	   // consultaPorCodigo
	   public String consultaPorCodCli() {
	      ResultSet rs;
	      String retorno  = "Saldo nao localizado !";
	      String conteudo = "";
	      try {
	         String sql = "SELECT saldo FROM tabSaldo WHERE codCliente = ?";
	         st         = conn.prepareStatement(sql);
	         st.setInt(1, getCodCliente());
	         rs         = st.executeQuery();
	         if (rs.next()) { // so espero um resultado por isso uso o IF para verificar
	            setSaldo(rs.getInt("saldo"));	// coloca-se os dados
	            conteudo += "R$ " +  rs.getInt   ("saldo");		
	            retorno = conteudo;
	         }
	         st.close(); // fecha consulta
				}
	      catch(Exception e) { e.printStackTrace(); }
	      return retorno; 
	   }
	   
	   //VoltarSaldo
	   public int voltarSaldo(int codCliente) {
		      ResultSet rs;
		      int retorno  = 0;
		      int conteudo = 0;
		      try {
		         String sql = "SELECT saldo FROM tabSaldo WHERE codCliente = ?";
		         st         = conn.prepareStatement(sql);
		         st.setInt(1, codCliente);
		         rs         = st.executeQuery();
		         if (rs.next()) { // so espero um resultado por isso uso o IF para verificar
		            setSaldo(rs.getInt("saldo"));	// coloca-se os dados
		            conteudo += rs.getInt   ("saldo");		
		            retorno = conteudo;
		         }
		         st.close(); // fecha consulta
					}
		      catch(Exception e) { e.printStackTrace(); }
		      return retorno; 
		   }
	            
	   // alterar
	   public boolean alterar(int saldo, int codCliente) {
	      boolean sucesso = false;
	      try {
	         String sql = "UPDATE tabSaldo SET saldo = ? WHERE codCliente = ?";
	         st = conn.prepareStatement(sql);
	         st.setInt(1,saldo);
	         st.setInt(2,codCliente);
	         st.executeUpdate();
	         sucesso = true;
	         st.close();
	      }
	      catch(Exception e) { e.printStackTrace(); }
	      db.closeConnection();
	      return sucesso; // retorna true se conseguiu alterar e false se nao conseguiu
	   }
	   
	// alterar2
	   public boolean alterar2(SaldoTO to) {
	      boolean sucesso = false;
	      try {
	         String sql = "UPDATE tabSaldo SET saldo = ? WHERE codCliente = ?";
	         st = conn.prepareStatement(sql);
	         st.setInt(1,to.getSaldo());
	         st.setInt(2,to.getCodCliente());
	         st.executeUpdate();
	         sucesso = true;
	         st.close();
	      }
	      catch(Exception e) { e.printStackTrace(); }
	      db.closeConnection();
	      return sucesso; // retorna true se conseguiu alterar e false se nao conseguiu
	   }
	   
	   // deletar
	   public boolean deletar() {
	      boolean sucesso = false;
	      try {
	         String sql = "DELETE FROM tabSaldo WHERE codSaldo = ?";
	         st         = conn.prepareStatement(sql);
	         st.setInt(1, getCodSaldo());
	         st.executeUpdate();
	         sucesso    = true;
	      }
	      catch(Exception e) {e.printStackTrace(); }
	      db.closeConnection();
	      return sucesso;
	   }
	   

}
