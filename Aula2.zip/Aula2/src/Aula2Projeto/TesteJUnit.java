package Aula2Projeto;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TesteJUnit {
	SaldoDAO saldoDAO;
	SaldoTO saldoTO;
	int valor =0;
	
	@Before  
	public void setUp() throws Exception {
		saldoTO.setCodCliente(1234);
		valor = saldoDAO.voltarSaldo(1234);
		saldoTO.setSaldo(valor);
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
	}
	
	@Test
	public void fazerSaqueTest(){
		
		valor = valor - 100;
		SaldoTO novo = new SaldoTO();
		novo.setCodCliente(1234);
		novo.setSaldo(valor);
		saldoDAO.alterar2(saldoTO);
		assertEquals("testa saque", novo, saldoTO);
	}
	
	

}
