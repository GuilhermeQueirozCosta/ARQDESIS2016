package Aula2Projeto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;

public class ExtratoContaTO {
	// atributos da classe
			private int codExtratoConta;
			private Date dataExtrato;
			private String debiCredi;
			private int numDocum;
			private int valorOpera;
			private int saldoDia;
			private String tipoExtrato;
			private int codCliente;
			private Connection conn;
			private PreparedStatement st;
			private MysqlConnect db;
			private Date data1;
			private Date data2;
			
			// set's
			public void setCodExtratoConta(int codExtratoConta) {
				this.codExtratoConta = codExtratoConta;
			}

			public void setDataExtrato(Date dataExtrato) {
				this.dataExtrato = dataExtrato;
			}

			public void setDebiCredi(String debiCredi) {
				this.debiCredi = debiCredi;
			}

			public void setNumDocum(int numDocum) {
				this.numDocum = numDocum;
			}
			
			public void setValorOpera(int valorOpera) {
				this.valorOpera = valorOpera;
			}

			public void setSaldoDia(int saldoDia) {
				this.saldoDia = saldoDia;
			}
			
			public void setTipoExtrato(String tipoExtrato) {
				this.tipoExtrato = tipoExtrato;
			}
			
			public void setCodCliente(int codCliente) {
				this.codCliente = codCliente;
			}
			
			public void setData1(Date data1) {
				this.data1 = data1;
			}
			
			public void setData2(Date data2) {
				this.data2 = data2;
			}
			
			// get's
			public int getCodExtratoConta() {
				return this.codExtratoConta;
			}

			public Date getDataExtrato() {
				return this.dataExtrato;
			}
			
			public String getDebiCredi() {
				return this.debiCredi;
			}
			
			public int getNumDocum() {
				return this.numDocum;
			}

			public int getValorOpera() {
				return this.valorOpera;
			}
			
			public int getSaldoDia() {
				return this.saldoDia;
			}
			
			public String getTipoExtrato() {
				return this.tipoExtrato;
			}
			
			public int getCodCliente() {
				return this.codCliente;
			}
			
			public Date getData1() {
				return this.data1;
			}
			
			public Date getData2() {
				return this.data2;
			}
}
